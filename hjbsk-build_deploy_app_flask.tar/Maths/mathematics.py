def summation(a, b){
    return a + b
}

def subtraction(a, b){
    return a - b
}

def multiplaction (a, b){
    return a * b
}